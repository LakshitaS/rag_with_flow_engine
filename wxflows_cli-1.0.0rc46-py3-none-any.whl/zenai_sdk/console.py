# Copyright IBM Corp. 2023, 2024

import types
from types import TracebackType
from typing import Optional, Type

from rich.console import Console, RenderableType
from rich.status import Status as RichStatus
from rich.style import StyleType


class Status(RichStatus):
    """Displays a status indicator with a 'spinner' animation. Unlike the
       default Status class, leaves the status message visible when done.

    Args:
        status (RenderableType): A status renderable (str or Text typically).
        done (str, optional): resolution text when completed without errors
        fail (str, optional): resolution text when completed with an error
        console (Console, optional): Console instance to use, or None for global console. Defaults to None.
        spinner (str, optional): Name of spinner animation (see python -m rich.spinner). Defaults to "dots".
        spinner_style (StyleType, optional): Style of spinner. Defaults to "status.spinner".
        speed (float, optional): Speed factor for spinner animation. Defaults to 1.0.
        refresh_per_second (float, optional): Number of refreshes per second. Defaults to 12.5.
    """

    def __init__(
        self,
        status: RenderableType,
        *,
        console: Optional[Console] = None,
        done: str = "[bright_black]done[/bright_black]",
        fail: str = "[red]fail[/red]",
        spinner: str = "dots",
        spinner_style: StyleType = "status.spinner",
        speed: float = 1.0,
        refresh_per_second: float = 12.5,
    ):
        # Call the superclass constructor with all the arguments
        super().__init__(
            status,
            console=console,
            spinner=spinner,
            spinner_style=spinner_style,
            speed=speed,
            refresh_per_second=refresh_per_second,
        )
        self.done = done
        self.fail = fail

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        self.stop()
        self.console.print(f"{self.status} {self.fail if exc_type else self.done}")


def status(
    self: Console,
    status: RenderableType,
    *,
    done: str = "[bright_black]done[/bright_black]",
    fail: str = "[red]fail[/red]",
    spinner: str = "dots",
    spinner_style: StyleType = "status.spinner",
    speed: float = 1.0,
    refresh_per_second: float = 12.5,
) -> Status:
    """Display a status and spinner.

    Args:
        status (RenderableType): A status renderable (str or Text typically).
        done (str, optional): resolution text when completed without errors
        fail (str, optional): resolution text when completed with an error
        spinner (str, optional): Name of spinner animation (see python -m rich.spinner). Defaults to "dots".
        spinner_style (StyleType, optional): Style of spinner. Defaults to "status.spinner".
        speed (float, optional): Speed factor for spinner animation. Defaults to 1.0.
        refresh_per_second (float, optional): Number of refreshes per second. Defaults to 12.5.

    Returns:
        Status: A Status object that may be used as a context manager.
    """

    return Status(
        status,
        console=self,
        done=done,
        fail=fail,
        spinner=spinner,
        spinner_style=spinner_style,
        speed=speed,
        refresh_per_second=refresh_per_second,
    )


console = Console(highlight=False)
console.status = types.MethodType(status, console)
