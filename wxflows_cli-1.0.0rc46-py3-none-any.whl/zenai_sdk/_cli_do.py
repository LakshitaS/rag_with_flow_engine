# Copyright IBM Corp. 2023, 2024

"""
stepzen.zenai operations
"""
import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple
from urllib.parse import urlparse

import httpx
import tomlkit
import tomlkit.items
import yaml

from ._cli_clidata import CLIData, ExtensionsArguments, _get_vup
from ._cli_do_loader import upload_and_process_local
from .cli_error import (
    CLIError,
    CLIStepzenConfiguration,
    CLIStepzenConfigurationLogin,
    CLIStepzenConfigurationLoginBad,
)
from .configuration import TOMLConfiguration, _WATZENTOML
from .console import console
from .flows import FlowFoundation, FlowsPublisher
from .stepzen_services import (
    IntrospectionMessage,
    IntrospectionServices,
    SchemaFileData,
    StepzenConfig,
    StepzenConfigYaml,
    StepzenLogin,
)

debug_level = 0

logger = logging.getLogger("wxflows")


def cmd_setup(
    location: str,
    feature_flags: Optional[List[str]] = [],
    verbose: bool = False,
    command: str = "",
) -> CLIData:

    # defaults
    account = ""
    domain = ""
    password = ""

    for i in range(10):
        try:
            clidata = CLIData.create(
                location,
                feature_flags,
                verbose=verbose,
            )
            return clidata
        except CLIStepzenConfiguration as e:
            if str(e) != str(CLIStepzenConfigurationLogin) and str(e) != str(
                CLIStepzenConfigurationLoginBad
            ):
                raise
            if command == "login" or command == "whoami":
                return CLIData()  # invalid CLIData
            if command:
                raise

        try:
            _ = CLIData.login(account, domain, password)
        except Exception as e:
            print("Please try again")
            logger.debug(f"login retry {e}")

    # retry a few times and then give up
    raise CLIError(
        f"Login failure on environment {account} in domain {domain} after repeated tries.   "
    )


def getspawnenv(
    cli: CLIData,
    toml_data: TOMLConfiguration,
) -> Dict[str, str]:
    # pass in current env to stepzen deploy
    env = os.environ.copy()
    # copy in our copy of values including overrides
    # may duplicate some STEPZEN_ values but we must get autoinjected ones.
    for k in cli.env_values:
        v = cli.env_values.get(k)
        if v is not None:  # if value is empty, then skip
            env[k] = v
    # for now, add in certain TOML values.
    pattern_env = toml_data.pattern_env()
    if not pattern_env:
        return env

    # could do pattern_env.update(env)
    logger.debug(f"Appending {len(pattern_env)} env vars from TOML")

    for k in pattern_env:
        if k not in env:
            env[k] = pattern_env[k]
    return env


def public_query_access_policy(public_queries: Optional[List[str]]):
    if not public_queries:
        return {}
    public_queries = [str(x) for x in public_queries]  # toml to str
    access_policy = {
        "policies": [
            {
                "type": "Query",
                "policyDefault": {"condition": False},
                "rules": [
                    {
                        "name": "allowed",
                        "fields": public_queries,
                        "condition": "true",
                    }
                ],
            }
        ]
    }
    logger.debug(f"Access policy: {json.dumps(access_policy)}")

    return access_policy


README_WD = """
This folder contains a dump of the schema and configuration file as:
- dump.schema.json - schema in deploy format
- dump.schema.yaml - included since it the content is more readable
- dump.config.yaml - configuration as deployed (with env substitutions)
  - only if --working-directory-unsafe-dump-final-config-yaml is specified as this is unsafe.
"""


def dump_for_deploy(
    working_directory: Optional[str], want_config: Optional[bool], foundation: FlowFoundation
):
    if not working_directory:
        return
    logger.debug(f"dump files to '{working_directory}'")
    # should tighten this code
    if foundation.endpoint_schema or foundation.configuration_data:
        with open(os.path.join(working_directory, "README.txt"), "w") as f:
            f.write(README_WD)
    if foundation.endpoint_schema:
        with open(os.path.join(working_directory, "dump.schema.json"), "w") as f:
            f.write(json.dumps(foundation.endpoint_schema.schema_files()))
        # also dump in yaml format for now.
        with open(os.path.join(working_directory, "dump.schema.yaml"), "w") as f:
            yaml.safe_dump(foundation.endpoint_schema.schema_files(), f)
    if foundation.configuration_data and want_config:

        def multiline(dumper, data):
            if "\n" in data:
                return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
            return dumper.represent_scalar("tag:yaml.org,2002:str", data)

        yaml.add_representer(str, multiline, Dumper=yaml.SafeDumper)

        def custom_opener(path, flags):
            return os.open(path, flags, mode=0o600)

        with open(
            os.path.join(working_directory, "dump.config.yaml"), "w", opener=custom_opener
        ) as f:
            yaml.safe_dump(foundation.configuration_data.get_configuration(), f)


async def process_deployment(
    endpoint_deployment: Optional[Mapping[str, Any]], foundation: FlowFoundation
):
    """
    any of these allowed, jwksendpoint is *required*
    in order to set deployment identity
    """

    # deployment.identity.issuer=""
    # deployment.identity.subject=""
    # deployment.identity.audience=""
    # deployment.identity.claims=[]
    # deployment.identity.jwksendpoint=""
    # deployment.identity.oidcconfigurationendpoint
    # deployment.identity.userinfoendpoint
    # deployment.identity.introspectendpoint

    if not endpoint_deployment:
        return

    found = [
        k
        for k in [
            "issuer",
            "subject",
            "audience",
            "claims",
            "jwksendpoint",
            # zenctl2 does not support as of 2024-05-03
            # "oidcconfigurationendpoint",
            # "userinfoendpoint",
            # "introspectendpoint",
        ]
        if k in endpoint_deployment.get("identity", {})
    ]
    # for now, always refresh jwksendpoint if this exists
    jwks_uri = endpoint_deployment.get("identity", {}).get("jwksendpoint")
    oidc_endpoint = endpoint_deployment.get("identity", {}).get("oidcconfigurationendpoint")
    if oidc_endpoint:
        async with httpx.AsyncClient() as client:
            result = await client.get(oidc_endpoint)
            config = result.json()
            if config.get("jwks_uri"):
                jwks_uri = config.get("jwks_uri")
                # set in the TOML data, but we are not going to write it back out.
                print(f"Setting jwks_uri {jwks_uri} from {oidc_endpoint}")
                endpoint_deployment["identity"]["jwksendpoint"] = jwks_uri
                logger.debug(
                    f"jwks_uri from oidc configuration endpoint {oidc_endpoint} is {jwks_uri}"
                )
            else:
                raise RuntimeError(
                    f"OIDC Configuration Endpoint {oidc_endpoint} is missing the jwks_uri"
                )
    if "jwksendpoint" not in found and not jwks_uri:
        # wasn't found, wasn't retrieved
        return

    data = {k: endpoint_deployment.get("identity", {}).get(k) for k in found}
    logger.debug(f"deployment.identity {data}")
    if not foundation.configuration_data:  # CLEAN
        foundation.configuration_data = StepzenConfig(None)
    foundation.configuration_data.set_value("deployment", {"identity": data})


def process_toml_configuration(
    endpoint_configuration: Optional[Mapping[str, Any]], foundation: FlowFoundation
):
    """
        configuration in the form:
    [wxflows.deployment.]
    configuration.joe.f="a"
    configuration.joe.y="a"
    where joe is the configuration name, are the named values.
    """
    if not endpoint_configuration:
        return
    for config_name, kv in endpoint_configuration.items():
        foundation.add_configuration(config_name, kv)
        logger.debug(f"configuration: adding {','.join([k for k in kv])} to {config_name}")

    pass


def user_directory(
    location: str,
    overlay: bool = False,
    remove_root: bool = False,
    subfolder: str = "",
) -> Tuple[Optional[List[SchemaFileData]], Optional[str], Optional[Dict[str, Any]]]:
    stem = Path(location).stem
    config: Optional[Dict[str, Any]] = None
    sfds: Optional[List[SchemaFileData]] = []

    if os.path.exists(os.path.join(location, "config.yaml")):
        with open(os.path.join(location, "config.yaml")) as f:
            config = yaml.safe_load(f)

    # return index if not overlay and file exists
    index: Optional[str] = None
    if not overlay:
        # note: this will only work with lowercase!
        # priority goes to latest atom.graphql model
        pindex: Optional[Path] = None
        if os.path.exists(os.path.join(location, "atom.graphql")):
            pindex = Path(stem).joinpath("atom.graphql")
        elif os.path.exists(os.path.join(location, "index.graphql")):
            pindex = Path(stem).joinpath("index.graphql")
        if pindex:
            if subfolder:
                pindex = Path(subfolder).joinpath(pindex)
            index = str(pindex)  # convert

    for root, dir, files in os.walk(location, followlinks=True):
        graphql = [item for item in files if os.path.splitext(item)[1] == ".graphql"]
        if not graphql:
            continue
        if remove_root:
            dirname = Path(root).relative_to(location)  # truncate
        else:
            # use last element of location (stem)
            dirname = Path(stem).joinpath(Path(root).relative_to(location))
            dirname = Path(subfolder).joinpath(dirname)
        for item in graphql:
            name = Path(root).joinpath(item)
            if name.is_file():
                sfd = SchemaFileData(dirname.joinpath(item).as_posix(), name.read_text())
                sfds.append(sfd)
    return sfds, index, config


def user_extensions(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    imported_extensions: Optional[List[SchemaFileData]],
    configuration_file: Optional[str],
    foundation: FlowFoundation,
):
    """
    handle user extension files or configuration
    user_extensions_directory: Optional[str],
      directory of user extension files [need root, assume index.graphql]
      also inserts config.yaml
    imported_extensions: Optional[List[SchemaFileData]],
      list of SchemaFileData already imported

    """
    if imported_extensions is None:
        imported_extensions = []

    sfds = imported_extensions
    if extensions.pattern_source_directories:
        # currently limited to 1 since it's not clear how multiple should be integrated
        # we could try to combine but each would have a `schema` and not a `extend schema`
        # so we would need to editting to ensure it's proper
        # likely, we'll just jam them together and let zenserv deal with it (it accepts
        # two `schema` directives?).
        for thedir in extensions.pattern_source_directories:
            # pattern_source_directory  will overlay this directory *onto* the schema.
            logger.debug(f"Extension: pattern source directory: {thedir}")
            # all the new entries should not be reported/logged.
            report_new = False
            xsfds, index, config = user_directory(thedir, overlay=True, remove_root=True)
            foundation.edit_add_overlay(xsfds, None, config, report_new=report_new)
            xsfdlen = len(xsfds) if xsfds else 0
            logger.debug(f"finished pattern source addition {thedir} file count {xsfdlen}")
    if extensions.user_extension_directories:
        for thedir in extensions.user_extension_directories:
            logger.debug(f"Extension: user directory: {thedir}")
            # subfolder is used to push down files a level from the root
            subfolder = "extension" if thedir == "" or thedir == "." else ""
            xsfds, index, config = user_directory(thedir, subfolder=subfolder)
            foundation.edit_add_user_folder(xsfds, index, config)
    nc = None
    if configuration_file:
        logger.debug(f"Extension: configuration_file: {configuration_file}")
        nc = StepzenConfigYaml(configuration_file, getspawnenv(cli, toml_data))
        if nc:
            console.print(f"Configuration data being loaded from {configuration_file}")
            logger.debug(f"configuration override: {configuration_file}")

    logger.debug(
        f"user edit: {len(sfds)}/{len(imported_extensions)} configuration: {nc is not None}"
    )
    if sfds or nc:
        foundation.edit(extensions=sfds, configuration=nc)


async def graphql_import_endpoints(
    login: StepzenLogin,
    endpoints: Mapping[str, Mapping[str, Any]],
    env: Any,
    foundation: FlowFoundation,
) -> List[SchemaFileData]:
    """
    [wxflows.deployment.endpoint.imports]
    name.url="https:..."
    name.prefix=""
    name.apikey_envname=""  # empty for user else None
    name.header.key=value
    """

    introspection = IntrospectionServices(login)
    schemas = []
    idx = 0
    if not endpoints:
        return []
    for name, endpoint in endpoints.items():
        url = endpoint.get("url")
        if not url:
            continue
        apikey = endpoint.get("apikey_envname")
        headers = introspection.apikey_header(
            env.get(apikey, None) if apikey else None, endpoint.get("header")
        )
        sdl = await introspection.import_graphql(url, headers, prefix=endpoint.get("prefix"))
        name = f"imported-graphql-{idx}.graphql"
        idx += 1
        logger.debug(f"imported {name} with sdl length {len(sdl)} from {url}")
        schema = SchemaFileData(f"imported-graphql-{idx}.graphql", sdl)
        schemas.append(schema)
    return schemas


def get_deploy_flows(
    console: Any,
    toml_data: TOMLConfiguration,
    arg_flows: Optional[List[str]],
    flow_files: Optional[List[str]],
) -> List[str]:
    """list of deployed flows"""

    # the configured flows in the TOML file should be one long string.
    configured_flows_data = toml_data.deployment_flows()
    configured_flows = []
    configured_flow_files = toml_data.deployment_flow_files()

    class Blanker:
        def __init__(self):
            self.blanked = False

        def do_blank(self):
            if not self.blanked:
                console.print("")
                self.blanked = True

        def do_blank_if_blank_issues(self):
            if self.blanked:
                console.print("")

    blanker = Blanker()
    if configured_flows_data and len(configured_flows_data) > 0:
        blanker.do_blank()
        console.print("Found flow definition in the configuration")
        configured_flows.append(configured_flows_data)

    if arg_flows and len(arg_flows) > 0:
        blanker.do_blank()
        console.print(
            f"Found {len(arg_flows)} command line flow{'s' if len(arg_flows) > 1 else ''}"
        )
        for flow in arg_flows:
            # console.print(f"  {flow}")
            logger.debug(f"flow: {flow}")
        configured_flows.extend(arg_flows)  # add MORE

    flow_file_data = []

    def read_ff(flow_files: Optional[List[str]]):
        if not flow_files:
            return
        for flow_name in flow_files:
            try:
                with open(flow_name, "r") as f:
                    data = f.read()
            except FileNotFoundError as e:
                raise CLIError(f"{flow_name} cannot be read: {e}")
            logger.debug(f"flow file: {flow_name}")
            flow_file_data.append(data)

    if configured_flow_files and len(configured_flow_files) > 0:
        blanker.do_blank()
        console.print(
            f"Found {len(configured_flow_files)} flow file{'s' if len(configured_flow_files) > 1 else ''} in the configuration"
        )
        read_ff(configured_flow_files)
        pass

    if flow_files and len(flow_files) > 0:
        blanker.do_blank()
        console.print(
            f"Found {len(flow_files)} flow file{'s' if len(flow_files) > 1 else ''} as an argument"
        )
        read_ff(flow_files)
        pass
    blanker.do_blank_if_blank_issues()
    configured_flows = flow_file_data + configured_flows
    return configured_flows


def report_messages(messages: List[IntrospectionMessage]) -> bool:
    error = False
    for message in messages:
        if message.level == "Error":
            console.print(f"[red]{message.level}[/red]: {message.message}")
            error = True
        elif message.level == "Warning":
            console.print(f"[yellow]{message.level}[/yellow]: {message.message}")
        else:
            console.print(f"{message.level}: {message.message}")
        if message.location:
            console.print(message.location)
    return error


def cmd_graph_deploy_zenctl(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    configuration_file: Optional[str],
    arg_flows: Optional[List[str]],
    flow_files: Optional[List[str]],
    working_directory: str = "",
    dump_config: Optional[bool] = False,
    expert: bool = False,
):
    # DROPPED from gcp: preexisting_endpoint, endpoint import (redone)
    pattern = toml_data.pattern()
    endpoint_name = toml_data.endpoint_name()

    public_queries = toml_data.deployment_public_queries()

    endpoint = toml_data.deployment_endpoints()
    if not configuration_file:  # cmd line wins
        configuration_file = toml_data.deployment_configuration_file()

    logger.debug(f"deploying... {pattern} {endpoint_name}")
    deploy_flows = get_deploy_flows(console, toml_data, arg_flows, flow_files)

    login = StepzenLogin(
        cli.account, cli.domain, cli.adminkey, service_instances=cli.service_instance
    )
    if cli.is_feature("introspection-steprz"):
        print("introspection-steprz")
        login.edit(StepzenLogin.INTROSPECTION_STAGING)

    env = getspawnenv(cli, toml_data)

    console.print("[bold]Provisioning the watsonx.ai flows engine environment[/bold]")

    async def dorun():
        have_pattern_source = (
            extensions.pattern_source_directories
            and len(extensions.pattern_source_directories) > 0
        )

        foundation = await FlowFoundation.create(
            pattern, login, env, use_pattern=not have_pattern_source
        )
        if public_queries and foundation.configuration_data:  # clean peek
            foundation.configuration_data.set_value(
                "access", public_query_access_policy(public_queries)
            )

        imported_extensions = await graphql_import_endpoints(
            login, endpoint.imports, env, foundation
        )
        # these edit the configuration and may add user specific values
        # which will get added to the base.  That has to be okay
        # but that means we can never trust the base to have a "safe" configuration
        user_extensions(
            cli,
            toml_data,
            extensions,
            imported_extensions,
            configuration_file,
            foundation,
        )
        process_toml_configuration(endpoint.configuration, foundation)
        dump_for_deploy(
            working_directory, dump_config, foundation
        )  # extra dump in case of an error
        await process_deployment(endpoint.deployment, foundation)
        pub = FlowsPublisher(foundation, login)
        try:
            result = await pub.deploy(endpoint_name, deploy_flows)
            logger.debug(
                f"deploy count {result.flows_count()} {result.flows_names()}  {result.uri}"
            )

        except RuntimeError as e:
            raise CLIError("An error occurred while deploying the endpoint: " + str(e))

        # foundation is modified by FlowsPublisher to include flows
        # For now, that's good because we want to dump them.
        dump_for_deploy(working_directory, dump_config, foundation)
        return result

    start = time.time()
    with console.status(f"Deploying the [yellow]{endpoint_name}[/yellow] endpoint..."):
        result = asyncio.run(dorun())
        iter = ""
        report_messages(result.messages())
        # clean this up later
        if not result.deploy_result.stepzen_deploy:
            raise CLIError("error occurred while deploying flows")

        cnt = result.flows_count()
        if cnt == 0:
            # remove this
            # if len(deploy_flows): console.print("  Flows specification did not contain a flow definition")
            console.print(f"Published {result.endpoint_url} in {round(time.time()-start,3)}s")
        else:
            if cnt and cnt > 1:
                iter = "s"
            if len(deploy_flows) <= 1:
                iter = ""
            names = ", ".join(result.flows_names())
            console.print(
                f"Published flow{iter} {names} to {result.endpoint_url} in {round(time.time()-start,3)}s"
            )
            logger.debug(
                f"Published flow{iter} {names} to {result.endpoint_url} in {round(time.time()-start,3)}s"
            )
    pass


def _get_toml(location: str) -> Tuple[str, tomlkit.TOMLDocument]:
    """get toml loads toml from specified location (directory or file )"""
    tf = None
    if os.path.isfile(location):
        tf = location
    else:
        if os.path.isfile(os.path.join(location, _WATZENTOML)):
            tf = os.path.join(location, _WATZENTOML)
    if not tf:
        raise CLIError(f"{_WATZENTOML} file not found in '{location}'")

    with open(tf, "rb") as f:
        tomldata = tomlkit.parse(f.read())
    output_directory = os.path.dirname(tf)
    return output_directory, tomldata


def _resolve_path(relative_or_absolute_path, base_directory):

    # limit to these cases  or else will cause issues on windows
    if "://" in relative_or_absolute_path and (
        relative_or_absolute_path[0] != "."
    ):  # is it a URI?
        parsed_url = urlparse(relative_or_absolute_path)
        if parsed_url.scheme:
            return relative_or_absolute_path

    if os.path.isabs(relative_or_absolute_path):
        # Return the path as-is if it's absolute
        return relative_or_absolute_path
    else:
        # Resolve the path relative to the base_directory
        return os.path.normpath(os.path.join(base_directory, relative_or_absolute_path))


def cmd_deploy(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    configuration_file: Optional[str],
    flows: Optional[List[str]],
    flow_files: Optional[List[str]],
    working_directory: str,
    dump_config: Optional[bool],
    collection_mode: str,
):
    cmd_graph(
        cli,
        "deploy",
        toml_data,
        extensions,
        configuration_file,
        flows,
        flow_files,
        working_directory,
        dump_config,
    )
    """run collection and graph deploy"""
    # keep deploy simple and use defaults.
    if collection_mode == "skip":
        return
    console.print("")
    cmd_collection(cli, "deploy", toml_data, collection_mode, False)

    pass


def cmd_graph(
    cli: CLIData,
    subcommand: str,
    toml_data: TOMLConfiguration,
    extensions: ExtensionsArguments,
    configuration_file: Optional[str],
    flows: Optional[List[str]],
    flow_files: Optional[List[str]],
    working_directory: str = "",
    dump_config: Optional[bool] = False,
):
    """
    build or deploy based on location/wxflows.toml or location (as a toml)
    """

    logger.debug("[wxflowscli]")
    if working_directory:
        os.makedirs(working_directory, exist_ok=True)
    cmd_graph_deploy_zenctl(
        cli,
        toml_data,
        extensions,
        configuration_file,
        flows,
        flow_files,
        working_directory=working_directory,
        dump_config=dump_config,
    )


def cmd_collection(
    cli: CLIData,
    subcommand: str,
    toml_data: TOMLConfiguration,
    collection_mode: Optional[str],
    direct: bool = True,
):
    """
    run collection processes (remotely)
    direct = True if called directly, else as a cmd_deploy which we'll use to effect
    slight behavior differences.

    TODO: add in cli object, use that instead of calling get_stepzen_admin
    """
    output_directory = toml_data.toml_location()
    pattern = toml_data.pattern()
    if pattern == "graphql":
        return  # nothing to do

    if toml_data.pattern_data() is None:
        if direct:  # more info
            print(f"missing deployment section for {pattern} wxflows.deployment.{pattern}")
            print("Stopping...")
        return

    if not collection_mode:
        collection_mode = "replace"

    tsv_files = toml_data.pattern_tsv_files()
    if not tsv_files:
        if direct:  # more info
            print("No input data was initialized so the collection deploy is being skipped")
            print(
                f"You can must have collection, tsv_files, and embedding setup in wxflows.deployment.{pattern}"
            )
            print("Stopping...")
        return
    # if we got this far, we must have collection and embedding_model
    collection = toml_data.pattern_collection()
    if not collection:
        raise CLIError("Missing collection name!  wxflows.deployment.collection")

    embedding_model = toml_data.pattern_embedding_model()
    if not embedding_model:
        raise CLIError(f"embedding model is required!  wxflows.deployment.{pattern}")

    account = cli.account_domain

    console.print(f"Creating or updating the [bold]{collection}[/bold] collection")

    docstore = toml_data.pattern_docstore()
    if not docstore:
        raise CLIError(
            f"This pattern {toml_data.pattern()} either does not support uploads or is missing documentstore information"
        )
    else:
        # later: pickup the first listed even if type is not listed
        docstore_type = docstore.type()
        docstore_data_file = docstore.data_file()
        docstore_subtype = docstore.subtype()

    # since the fallback for search_engine is docstore type this
    # is a pointless check except for pyright...
    search_engine = toml_data.pattern_search_engine()
    if not search_engine:
        raise CLIError("search_engine is not known")
    zup = _get_vup(cli, toml_data, account, "documentstore")

    consolemsg = ""
    if docstore_data_file:
        consolemsg += " datafile {docstore_data_file}"
    if docstore_subtype:
        console.print(
            f"Using {zup.endpoint} for uploading{consolemsg} into search engine type: {docstore_type}.{docstore_subtype}"
        )
    else:
        console.print(
            f"Using {zup.endpoint} for uploading{consolemsg} into search engine type: {docstore_type}"
        )

    upload_and_process_local(
        console,
        cli,
        None,  # TODO
        zup,
        account,
        [_resolve_path(name, output_directory) for name in tsv_files],
        collection,
        embedding_model,
        docstore_data_file,
        docstore_type,
        docstore_subtype,
        search_engine,
        True,
        True,
        collection_mode,
    )


def cmd_login(
    cli: CLIData,
    environment_arg: Optional[str],
    adminkey_arg: Optional[str],
    domain_arg: Optional[str],
    introspection_arg: Optional[str],
):

    if introspection_arg:
        # enough for now.
        if introspection_arg.startswith("http"):
            introspection = introspection_arg
        else:
            introspection = f"https://{introspection_arg}"
        logger.debug(f"Introspection {introspection}")
    else:
        introspection = ""

    # check to see if the configuration file exists, if not check if the user wants to refresh
    try:
        _ = cli.account
    except AttributeError:
        try:

            CLIData.overwrite_check()
        except CLIStepzenConfiguration:
            print("okay, will not overwrite existing login information")
            return

    try:
        _ = CLIData.login(
            environment_arg,
            domain_arg,
            adminkey_arg,
            introspection,
        )
    except Exception as e:
        raise CLIError(str(e))
    pass


def cmd_whoami(cli: CLIData, whoami: Optional[str]):

    logger.debug(f"whoami {whoami}")
    try:
        _ = cli.account
    except Exception:
        logger.debug(f"whoami {whoami} - no CLIData")
        print("You are not logged in")
        return

    if whoami == "e":
        print(f"{cli.account}")
    elif whoami == "A":
        print(f"{cli.adminkey}")
    elif whoami == "a":
        print(f"{cli.apikey}")
    elif whoami == "d":
        print(f"{cli.domain}")
    elif whoami == "j":
        print(
            json.dumps(
                {
                    "domain": cli.domain,
                    "environment": cli.account,
                    "adminKey": cli.adminkey,
                    "apiKey": cli.apikey,
                }
            )
        )
    else:
        print()
        print(f"Domain: {cli.domain}")
        print(f"Environment: {cli.account}")

        def mask_key(s):
            parts = s.split("::")
            if len(parts) < 3:
                return len(s) * "*"
            if len(parts[2]) < 20:  # if too short, then we end up showing the key
                return "::".join([parts[0], parts[1], len(parts[2]) * "*"])
            return "::".join(
                [parts[0], parts[1], parts[2][0:2] + (len(parts[2]) - 4) * "*" + parts[2][-2:]]
            )

        print(f"Admin key: {mask_key(cli.adminkey)}")
        print(f"Api key: {mask_key(cli.apikey)}")
