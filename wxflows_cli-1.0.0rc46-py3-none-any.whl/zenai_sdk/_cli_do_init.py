# Copyright IBM Corp. 2023, 2024
import asyncio
import json
import logging
import os
import re
import sys
from typing import Dict, List, Optional, Union, cast

import inquirer
from inquirer.errors import ValidationError as InquirerValidationError
from jinja2 import DebugUndefined, Environment, PackageLoader, select_autoescape
from rich import print as rprint

from ._cli_do import _WATZENTOML, CLIData
from ._cli_do_data import cmd_data
from .cli_error import CLIError
from .console import console
from .flows import CatalogData
from .configuration import (
    TOMLConfiguration,
    _DEFAULT_COLLECTION,
    _DEFAULT_DOCSTORE,
    _DEFAULT_GENAI,
)

logger = logging.getLogger("wxflows")


FIXED_FLOW_TEXT = """\"\"\"
    // myPrompt = ragAnswerInput | topNDocs | promptFromTopN | ragInfo
    // myRag = ragAnswerInput | topNDocs | promptFromTopN | completion(parameters:myRag.parameters) | ragInfo
    // myRagWithGuardrails = ragAnswerInput | topNDocs | promptFromTopN | completion(parameters:myRagWithGuardrails.parameters) | ragScoreInfo | hallucinationScore | ragScoreMessage | ragInfo
\"\"\""""

DEFAULT_AI_ENGINE = _DEFAULT_GENAI
DEFAULT_DOCUMENTSTORE = _DEFAULT_DOCSTORE
DEFAULT_COLLECTION = _DEFAULT_COLLECTION


def _validate_collection_name(_, current: str) -> bool:
    if len(current.strip()):
        return True

    raise InquirerValidationError("", reason="A collection name is requried")


def _validate_endpoint_name(_, current: str) -> bool:
    if not current or "/" not in current:
        raise InquirerValidationError(
            "",
            reason="An endpoint name should look like [folder]/[name], and each part should be non-empty",
        )

    parts = current.split("/")
    if any(part.strip() == "" for part in parts):
        raise InquirerValidationError(
            "",
            reason="An endpoint name should look like [folder]/[name], and each part should be non-empty",
        )

    if any(re.match(r"^[\d_-]", part) for part in parts):
        raise InquirerValidationError(
            "", reason="Each part of an endpoint name should start with a letter"
        )

    if any(not re.match(r"^[\w-]+$", part) for part in parts):
        raise InquirerValidationError(
            "",
            reason="An endpoint name should contain only letters, digits, dashes and underscores",
        )

    return True


def is_tsv_file(path: str) -> bool:
    return os.path.isfile(path) and os.path.splitext(path)[1].lower() == ".tsv"


class DocumentStoreArguments:
    """
    just capture these cleanly
    """

    def __init__(
        self,
        documentstore_type: Optional[str],
        documentstore_data_file: Optional[str],
    ):
        if documentstore_type:
            parts = documentstore_type.split(".")
            self.documentstore_type = parts[0]
            self.documentstore_subtype = parts[1] if len(parts) > 1 else None
        else:
            self.documentstore_type = None
            self.documentstore_subtype = None
        self.documentstore_data_file = documentstore_data_file

    def get_toml_data(self) -> List[str]:
        if not self.documentstore_type:
            return []
        have = []
        have.append(f'documentstore.type="{self.documentstore_type}"')
        if self.documentstore_subtype:
            have.append(
                f'documentstore.{self.documentstore_type}.subtype="{self.documentstore_subtype}"'
            )

        if self.documentstore_data_file:
            have.append(
                f'document.{self.documentstore_type}.data_file="{self.documentstore_data_file}"'
            )
        return have


def cmd_init(
    clienv: CLIData,
    pattern: str,
    collection: str,
    files: List[str],
    name: Optional[str],
    email: Optional[str],
    interactive: bool,
    configuration_file: Optional[str],
    initial_configuration_file: Optional[bool],
    embedding: Optional[str],
    data_args: Dict[str, Union[str, int]],
    endpoint_name: Optional[str],
    preexisting_endpoint: Optional[str],  # base endpoint in lieu of pattern (DEPRECATED)
    ai_engine: Optional[str],
    ds_arguments: Optional[DocumentStoreArguments],
    directory: Optional[str] = "",
):
    """
    create the wxflows.toml
    """

    if not directory:
        directory = ""

    if endpoint_name:
        try:
            _validate_endpoint_name({}, endpoint_name)
        except InquirerValidationError as e:  # type: ignore
            raise CLIError(f"Invalid endpoint name {endpoint_name}. {e.reason}")

    if not clienv.is_zenctl2():
        raise CLIError(
            "watsonx.ai flows engine does not work with your current StepZen environment.  Please upgrade your enviroment at https://ibm.biz/wxflows-dashboard"
        )

    # *FIXED_FLOW_TEXT* needs to be cleanup and gotten from where?
    # should not be appending document store info

    # adjust default chunk size, but not the offset for now.
    default_chunk_size = "500"
    if (
        embedding == "mini"
        or embedding == "sentence-transformers/all-minilm-l12-v2"
        or embedding == "sentence-transformers/all-minilm-l6-v2"
    ):
        default_chunk_size = "250"
    if not embedding:
        # default to the WATSONX default embedding
        embedding = "ibm/slate-30m-english-rtrvr"

    # aicore is the only thing we accept as pattern
    # pattern was originally the term for the schemas we'd used
    # for a particular "use" case.   It has since evolved, but it
    # remains in the code.  While there may be multiple schema
    # types in the future, we'll likely want to rename it from pattern...
    pattern = "aicore"

    # skip manifest elements if preexisting_endpoint is true since
    # manifest elements will not apply
    bundle = None
    catalog_data = asyncio.run(CatalogData.create())
    if not catalog_data.get_pattern(pattern):
        raise CLIError(
            "internal error: the aicore definition could not be found or is inaccessible"
        )

    # interactive prompt if collection is not provided (RAG-specific)
    dorag = "no"
    # interactive prompt if asked
    if interactive:
        questions = [
            inquirer.List(
                "dorag",
                message="Do you wish to use retrieval-augmented generation (RAG)?",
                choices=["yes", "no"],
                default="yes",
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        dorag = cast(str, answers.get("dorag"))

    if not collection and dorag == "yes":
        questions = [
            inquirer.List(
                "collection_or_type",
                message="Choose the document collection for context retrieval",
                choices=[
                    ("create from local data", "data"),
                    ("use custom", "custom"),
                ],
            ),
        ]
        answers = inquirer.prompt(questions)
        if not answers:
            # the prompt is interrupted by the user with Ctrl+C
            sys.exit(0)
        collection_or_type = cast(str, answers.get("collection_or_type"))

        if collection_or_type == "data":
            questions = [
                inquirer.Path(
                    "data_directory",
                    message="Path to the data",
                    exists=True,
                    default=data_args.get("data_directory"),
                ),
                inquirer.List(
                    "data_type",
                    message="File types to include",
                    choices=[
                        ("Markdown or HTML(ignore other files)", "md"),
                        ("all supported file types", "auto"),
                    ],
                    default=data_args.get("data_type") or "md",
                    ignore=lambda x: is_tsv_file(x["data_directory"]),  # type: ignore
                ),
                inquirer.Text(
                    "chunk_size",
                    message="Chunk size (in tokens)",
                    validate=lambda _, value: value.strip().isdigit(),
                    default=data_args.get("chunk_size") or default_chunk_size,
                    ignore=lambda x: is_tsv_file(x["data_directory"]),  # type: ignore
                ),
                inquirer.Text(
                    "chunk_overlap",
                    message="Chunk overlap (in tokens)",
                    validate=lambda _, value: value.strip().isdigit(),
                    default=data_args.get("chunk_overlap") or "50",
                    ignore=lambda x: is_tsv_file(x["data_directory"]),  # type: ignore
                ),
                inquirer.Text(
                    "collection",
                    message="Collection name",
                    default="wxflows-default",
                    validate=_validate_collection_name,
                ),
            ]
            if not endpoint_name:
                questions.append(
                    inquirer.Text(
                        "endpoint",
                        message="Endpoint name",
                        default=lambda answers: TOMLConfiguration._default_endpoint_name(
                            pattern, answers["collection"]
                        ),
                        validate=_validate_endpoint_name,
                    ),
                )
            answers = inquirer.prompt(questions)
            if not answers:
                # the prompt is interrupted by the user with Ctrl+C
                sys.exit(0)
            collection = cast(str, answers.get("collection"))
            endpoint_name = cast(str, answers.get("endpoint"))
            for k in "data_directory", "data_type":
                data_args[k] = cast(str, answers[k])
            # convert token count to character count
            for k in "chunk_size", "chunk_overlap":
                data_args[k] = int(cast(str, answers[k]))
        elif collection_or_type == "custom":
            questions = [
                inquirer.Text(
                    "collection",
                    message="Collection name",
                    default=DEFAULT_COLLECTION,
                    validate=_validate_collection_name,
                ),
            ]
            if not endpoint_name:
                questions.append(
                    inquirer.Text(
                        "endpoint",
                        message="Endpoint name",
                        default=lambda answers: TOMLConfiguration._default_endpoint_name(
                            pattern, answers["collection"]
                        ),
                        validate=_validate_endpoint_name,
                    ),
                )
            answers = inquirer.prompt(questions)
            if not answers:
                # the prompt is interrupted by the user with Ctrl+C
                sys.exit(0)
            collection = cast(str, answers.get("collection"))
            endpoint_name = cast(str, answers.get("endpoint"))
        else:
            # default is collection name
            collection = collection_or_type
    else:
        if interactive:
            print(
                "Please refer to https://ibm.biz/wxflows-dashboard for more information on usages other than RAG"
            )

    if not endpoint_name:
        # skipped interactive prompts, and no endpoint was provided on the command line
        endpoint_name = TOMLConfiguration._default_endpoint_name(pattern, collection)

    if not ai_engine:
        logger.debug(f"ai_engine defaulting to {DEFAULT_AI_ENGINE}")
        ai_engine = DEFAULT_AI_ENGINE
    logger.debug(f"ai_engine: {ai_engine}")

    vars = {
        "email": email,
        "name": name,
        "collection": collection,
        "endpoint_name": endpoint_name,
        "deployment_pattern": pattern,
        "files": json.dumps(files),
        "ai_engine": ai_engine,
        "configuration_file": configuration_file,
    }

    if preexisting_endpoint:
        # naming...
        vars["preexisting_endpoint"] = preexisting_endpoint

    vars["embedding_model"] = embedding

    # grab flows (sequences) from the current pattern
    if bundle:
        flowinfo = bundle.get_stepzen_sequence(pattern)
        if flowinfo:
            # toml is forgiving about extra commas, so add them in so
            # list is legal if there are multiple items
            vars["flows"] = ",\n\n".join(flowinfo)
    else:
        vars["flows"] = (
            json.dumps("  // You should add your flows here ")
            # hard code for now.  Drop inspection code which belongs in flow introspection
        )
        pass

    for name in ["data_type", "chunk_size", "chunk_overlap", "data_directory"]:
        if name in data_args:
            if not collection:
                logger.debug(
                    f"setting empty collection to {DEFAULT_COLLECTION} due to existence of {name}"
                )
                collection = DEFAULT_COLLECTION
            v = data_args[name]
            if name == "data_directory" and isinstance(v, str) and is_tsv_file(v):
                continue
            logger.debug(f"argument {name} set to {data_args[name]}")
            vars[name] = v

    # if collection then assume we need flows
    if collection:
        # figure out something better than FIXED_FLOW_TEXT though.
        vars["flows"] = FIXED_FLOW_TEXT

    need_data_build = data_args.get("data_directory") and not is_tsv_file(
        cast(str, data_args.get("data_directory"))
    )
    if data_args.get("data_directory"):
        if not files:  # don't overide files if set
            files = [
                (
                    f"{collection}.tsv"
                    if need_data_build
                    else f'{data_args.get("data_directory", "")}'
                )
            ]
            vars["files"] = json.dumps(files)
        elif any([("://" in f) for f in files]):
            raise CLIError("data_directory and URIs not allowed at this time.")

    if ds_arguments:
        # we should figure out the AI engine upstream and set it here...
        dstoml = ds_arguments.get_toml_data()
        if dstoml:
            vars["documentstore"] = dstoml
        else:
            # getting started uses the GETTINGSTARTED search engine
            vars["documentstore"] = [f'documentstore.type="{DEFAULT_DOCUMENTSTORE}"']

    # continue to use the jinja templating for the toml
    # consider moving to mustache templates as they are far more limited and work well on nodejs
    # and okay on golang.
    env = Environment(
        loader=PackageLoader("zenai_sdk"), autoescape=select_autoescape(), undefined=DebugUndefined
    )
    env.trim_blocks = True
    # setup all the fiddly bits
    template_name = "initial/wxflows.toml.tmpl"
    template = env.get_template(template_name)

    if directory and not os.path.exists(directory):
        os.makedirs(directory)

    watzen_toml = os.path.join(directory, _WATZENTOML)
    with open(watzen_toml, "w+", encoding="utf-8") as f:
        f.write(template.render(vars))

    # only write this on this path for now.
    dot_env = os.path.join(directory, ".env.sample")
    with open(dot_env, "w+", encoding="utf-8") as f:
        if preexisting_endpoint:
            # fix up this comment
            f.write("# API Key for the preexisting endpoint - not required if public\n")
            f.write("WXFLOWS_PREEXISTING_ENDPOINT_APIKEY=\n")
        elif catalog_data:
            # placeholder for .env.sample
            # clean up or move out and make more robust.
            stepzen_configuration = catalog_data.get_pattern_configuration(pattern)
            if not stepzen_configuration:
                print("warning: could not generate {dot_env}")
            else:
                restricted = []
                # if we're interactively doing rag, then limit choices for .env.sample
                if interactive and dorag == "yes":
                    restricted = ["STEPZEN_WATSONX_"]
                lines = [
                    "# -- Auto-generated once by wxflows init. Edit as required and save as .env --"
                ] + [
                    f"{'# ' if item not in os.environ else ''}{item}="
                    for item in sorted(stepzen_configuration.get_configuration_env())
                    if item not in clienv._injected.keys()
                    and (
                        not restricted
                        or any(
                            [item for restriction in restricted if item.startswith(restriction)]
                        )
                    )
                ]
                f.write("\n".join(lines) + "\n")
    if configuration_file and os.path.exists(configuration_file):
        raise CLIError("Will not overwrite existing configuration file")

    if catalog_data and initial_configuration_file:  # TODO: add a flag
        writefile = configuration_file if configuration_file else "wxflows-config.yaml"
        stepzen_configuration = catalog_data.get_pattern_configuration(pattern)
        if not stepzen_configuration:
            print("warning: could not generate {dot_env}")
        else:
            with open("config.yaml", "w") as f:
                f.write(stepzen_configuration.get_configuration_file())
        configfile_msg = f" and [bold]{writefile}[/bold]"
    else:
        configfile_msg = ""
    data_file_msg = ""
    if need_data_build and interactive:
        rprint("Processing data...")

        cmd_data(
            console,
            clienv,
            TOMLConfiguration(watzen_toml),
            command="data",
            args=data_args,
            force=False,
            emit_command=True,
        )
        data_file_msg = f", [bold]{files[0]}[/bold]"

    rprint(
        f"[green]success[/green]: created [bold]{watzen_toml}[/bold]{data_file_msg} and [bold]{dot_env}[/bold]{configfile_msg}"
        + "\nPlease review and edit these files and then run [bold]wxflows collection deploy[/bold] to deploy your pattern."
    )
