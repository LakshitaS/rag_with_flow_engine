# Copyright IBM Corp. 2023, 2024


from typing import Optional, Union

from rich.console import ConsoleRenderable


class CLIError(Exception):
    """
    Generic CLI error - throwing this will cause the CLI print the error message
    and exit with a non-zero status code.

    The main reason for creating a custom exception class is to avoid catching
    _all_ exceptions in the CLI's main loop, and still be able (i) use
    exceptions to signal errors from deep inside the CLI code and (ii) avoid
    printing stack traces for such errors.
    """

    def __init__(self, message: Union[ConsoleRenderable, str], code: Optional[int] = 1):
        self.message = message
        self.code = code
        pass


class CLIStepzenConfiguration(CLIError):
    """
    catches errors due to StepZen configuration.
    """

    def __init__(self, message: Union[ConsoleRenderable, str], code: Optional[int] = 1):
        self.message = message
        self.code = code
        pass


CLIStepzenConfigurationLogin = CLIStepzenConfiguration('Use the "wxflows login" command to login.')
CLIStepzenConfigurationLoginBad = CLIStepzenConfiguration(
    'Your existing stepzen login credentials are invalid.  Use the "wxflows login" command to login.'
)
