# Copyright IBM Corp. 2023, 2024

"""
wxflows CLI
"""
import argparse
import logging
import logging.config
import os
import sys
from typing import Dict, List, Union

from dotenv import load_dotenv
from rich.console import ConsoleRenderable
from rich.markup import escape

from .__about__ import __version__ as cmd_version
from ._cli_clidata import ExtensionsArguments
from ._cli_do import (
    _WATZENTOML,
    cmd_deploy,
    cmd_graph,
    cmd_setup,
    cmd_login,
    cmd_whoami,
)
from ._cli_do_data import cmd_data, cmd_data_annotate
from ._cli_do_eval import cmd_eval_collect, cmd_eval_ragas
from ._cli_do_init import DocumentStoreArguments, cmd_init
from .cli_error import CLIError
from .configuration import TOMLConfiguration
from .console import console


CLI_NAME = "wxflows"


def _init_logger() -> List[str]:
    """
    Use the same env var to enable debug logging in wxflows CLI as the one
     that's already used by StepZen CLI

     Example: DEBUG="stepzen:*,watzen" watzen init
    """
    debug_file = os.environ.get("WXFLOWS_DEBUG_LOGFILE", "")
    watzenScopes = [
        component
        for component in map(
            lambda s: s.strip(),
            os.environ.get("DEBUG", "").lower().split(","),
        )
        if component in ["*", "graphql", "http", "gql", "wxflows"]
        or component.startswith("wxflows.")
    ]
    if debug_file and not watzenScopes:
        watzenScopes = ["wxflows"]

    if watzenScopes:
        logger = logging.getLogger("wxflows")
        logger.debug(f"scope: {','.join(watzenScopes)}")
        logging.basicConfig(
            filename=debug_file,
            level=logging.WARNING,
            format="wxflows:%(levelname)s +%(relativeCreated)dms %(message)s",
        )
        logger.setLevel(logging.DEBUG)

        if "gql" in watzenScopes:
            logging.getLogger("gql").setLevel(logging.DEBUG)
            logging.getLogger("gql.client").setLevel(logging.DEBUG)
            logging.getLogger("gql.transport.requests").setLevel(logging.DEBUG)
            logging.getLogger("gql.transport.httpx").setLevel(logging.DEBUG)
            logger.debug("Logging GQL")

        if "http" in watzenScopes:
            logging.getLogger("httpx").setLevel(logging.DEBUG)
            logging.getLogger("httpcore").setLevel(logging.DEBUG)
            logger.debug("Logging HTTP")
    return watzenScopes


def _common_arguments(parser: argparse.ArgumentParser):
    parser.add_argument("--wxflows-configuration", default=_WATZENTOML, help=argparse.SUPPRESS)
    parser.add_argument(
        "--configuration-file",
        default=_WATZENTOML,
        help="watsonx.ai flows configuration",
        dest="watzen_configuration",
    )


def _common_deploy_graph(parser: argparse.ArgumentParser):
    _common_arguments(parser)
    parser.add_argument("--flow-file", help="flow definition file", action="append")
    # for internal and possibly external use, override the pattern files with files from this directory
    parser.add_argument(
        "--pattern-source-directory",
        help=argparse.SUPPRESS,
        dest="source_directory",
    )
    # for internal and possibly external use, override the core with files from this directory
    # use the less descriptive name because pattern isn't defined.
    parser.add_argument(
        "--source-directory",
        help=argparse.SUPPRESS,
        dest="source_directory",
    )

    # for internal use, add this directory into the schema as a subdirectory
    parser.add_argument(
        "--user-extension-directory",
        "-U",
        help=argparse.SUPPRESS,
        action="append",
        dest="user_extension_directories",
    )
    parser.add_argument("--flow", action="append", help=argparse.SUPPRESS)
    parser.add_argument(
        "--stepzen-configuration-file", help=argparse.SUPPRESS, dest="configuration_file"
    )

    parser.add_argument(
        "--temporary-directory",
        default=None,
        metavar="DEBUG_WORKING_DIRECTORY",
        dest="working_directory",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--working-directory",
        default=None,
        metavar="DEBUG_WORKING_DIRECTORY",
        dest="working_directory",
        help=argparse.SUPPRESS,
    )

    parser.add_argument(
        "--working-directory-unsafe-dump-final-config-yaml",
        action="store_true",
        help=argparse.SUPPRESS,
    )


def _setup_collection(parser: argparse.ArgumentParser):
    parser.set_defaults(command="collection")
    subparsers = parser.add_subparsers(help="sub-command help", required=True, dest="subcommand")
    parser_cmd = subparsers.add_parser(
        "deploy",
        help="deploy",
    )
    # collection deploy is now an alias for deploy
    _common_deploy_graph(parser_cmd)
    # remove this for now - interferes with endpoint
    # parser_cmd.add_argument("--collection", help="collection")
    parser_cmd.add_argument("--collection-mode", choices=["append", "replace"])


def _setup_graph(parser: argparse.ArgumentParser):
    parser.set_defaults(command="flows")
    subparsers = parser.add_subparsers(help="sub-command help", required=True, dest="subcommand")
    dparser = subparsers.add_parser("deploy", help="deploy flows core")
    _common_deploy_graph(dparser)


def _common_data_arguments(parser: argparse.ArgumentParser):
    """
    _common_data_directory_argument is the argument exposed in both data and init commands
    """

    # remove defaults so we can know what arguments the user has given
    # important for init
    # important to override init in the data command later
    parser.add_argument("--data-directory", help="folder with data files")
    parser.add_argument("--data-type", choices=["md", "auto", "html"])
    parser.add_argument("--chunk-size", type=int)
    parser.add_argument("--chunk-overlap", type=int)

    parser.add_argument(
        "--compute-embeddings", action="store_true", default=False, help="compute embeddings"
    )


class DataArguments:
    """
    trivial abstraction around arguments.
    use dicts for simplicity but separate into typed values for safety
    """

    def __init__(self, args: argparse.Namespace):
        self.data = {}
        if args.data_directory:
            self.data["data_directory"] = args.data_directory
        if args.data_type:
            self.data["data_type"] = args.data_type
        if args.chunk_size:
            self.data["chunk_size"] = args.chunk_size
        if args.chunk_overlap:
            self.data["chunk_overlap"] = args.chunk_overlap
        if args.compute_embeddings:
            self.data["compute_embeddings"] = args.compute_embeddings
        pass

    def get_data(self) -> Dict[str, Union[str, int]]:
        return self.data


def _parser_add_argument_embedding(parser: argparse.ArgumentParser):
    # we should get a list of the models and preload choices perhaps
    # but this requires knowing the ai_engine beforehand!
    parser.add_argument(
        "--embedding-model",
        "--embedding",
        metavar="MODEL",
        help="embedding model, defaults to mini (all-MiniLM-L6-v2)",
    )
    pass


def _setup_init(parser: argparse.ArgumentParser):
    parser.set_defaults(command="init")
    # mask these, but leave the code for now.
    parser.add_argument("--name", "-N", help=argparse.SUPPRESS, default="YOUR NAME")
    parser.add_argument("--email", "-E", help=argparse.SUPPRESS, default="EMAIL")

    # possibly use this to drive usage models but for now, let it fade into the background.
    parser.add_argument(
        "--pattern",
        "-p",
        choices=["aicore", "rag_v1"],
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--no-pattern", help=argparse.SUPPRESS, dest="pattern", action="store_const", const="null"
    )
    parser.add_argument("--endpoint-name", default=None, help="endpoint name")

    # hide this from view for now.
    parser.add_argument("--preexisting-endpoint", default="", help=argparse.SUPPRESS)
    # mask this for now.
    parser.add_argument("--document-store", help=argparse.SUPPRESS)
    parser.add_argument("--ai-engine", help="AI Engine", choices=["watsonx.ai"])
    parser.add_argument(
        "--bam", help=argparse.SUPPRESS, dest="ai_engine", const="BAM", action="store_const"
    )
    parser.add_argument("--document-store-data-file", help=argparse.SUPPRESS)

    _parser_add_argument_embedding(parser)

    _common_data_arguments(parser)
    parser.add_argument("--collection", "-C", help="this collection", default="", required=False)

    # configuration file can be used to specify a stepzen config.yaml
    parser.add_argument(
        "--stepzen-configuration-file", help=argparse.SUPPRESS, dest="configuration_file"
    )
    # initial will emit the template config.yaml from the pattern
    parser.add_argument(
        "--initial-stepzen-configuration-file",
        help=argparse.SUPPRESS,
        action="store_true",
        dest="initial_configuration_file",
    )
    parser.add_argument(
        "--interactive",
        dest="interactive",
        action="store_true",
        default=False,
        help="interactive prompting",
    )

    # finally
    parser.add_argument("files", help="TSV files to process", nargs="*")


def _setup_login(parser: argparse.ArgumentParser):
    parser.set_defaults(command="login")
    parser.add_argument("--environment", "-e", help="Environment name")
    parser.add_argument("--account", "-a", help=argparse.SUPPRESS, dest="environment")
    parser.add_argument("--adminkey", "-k", help="Admin key")
    parser.add_argument(
        "--introspection",
        help="Override the default StepZen introspection service URL for all stepzen import commands.",
    )
    parser.add_argument(
        "domain",
        metavar="DOMAIN",
        help="Domain of the StepZen service to login to (e.g. stepzen.acme.com)",
        default="",
        nargs="?",
    )


def _setup_whoami(parser: argparse.ArgumentParser):
    parser.set_defaults(command="whoami")
    action = parser.add_mutually_exclusive_group(required=False)
    parser.set_defaults(showkeys="_")
    action.add_argument(
        "--environment",
        dest="showkeys",
        action="store_const",
        const="e",
        help="show environment",
    )
    action.add_argument(
        "--account",
        dest="showkeys",
        action="store_const",
        const="e",
        help=argparse.SUPPRESS,
    )
    action.add_argument(
        "--adminkey", dest="showkeys", action="store_const", const="A", help="Show Admin key"
    )
    action.add_argument(
        "--apikey", dest="showkeys", action="store_const", const="a", help="Show API key"
    )
    action.add_argument(
        "--domain", dest="showkeys", action="store_const", const="d", help="Show domain"
    )
    action.add_argument(
        "--showkeys", dest="showkeys", action="store_const", const="_", help="Show keys"
    )
    action.add_argument("--json", dest="showkeys", action="store_const", const="j", help="JSON")


def _setup_deploy(parser: argparse.ArgumentParser):
    parser.set_defaults(command="deploy")
    _common_deploy_graph(parser)
    # disable these on `deploy`
    # parser.add_argument("--collection-mode", choices=["append", "replace", "skip"])
    # parser.add_argument("--no-upload", dest="collection_mode", action="store_const", const="skip")


def _setup_data(parser: argparse.ArgumentParser):
    parser.set_defaults(command="data")
    subparsers = parser.add_subparsers(
        help="sub-command help", required=True, dest="subcommand", metavar="{build}"
    )
    parser = subparsers.add_parser("build", help="build")
    _common_arguments(parser)
    _common_data_arguments(parser)
    parser.add_argument("--force", action="store_true", default=False)

    parser = subparsers.add_parser("annotate")
    parser.add_argument("--force", action="store_true", default=False)
    _parser_add_argument_embedding(parser)
    parser.add_argument(
        "--directive",
        choices=["convert-text", "combine-text"],
        help="combine-text will combine text and title as content, convert-text drops the title and text after the combine operation",
    )

    _common_arguments(parser)
    parser.add_argument("--output-file", "--output", required=True, help="output file")
    parser.add_argument("files", help="input files", nargs="+")


def _setup_eval(parser: argparse.ArgumentParser):
    parser.set_defaults(command="eval")
    subparsers = parser.add_subparsers(help="sub-command help", required=True, dest="subcommand")
    parser = subparsers.add_parser(
        "collect", help="collect", formatter_class=argparse.RawTextHelpFormatter
    )
    _common_arguments(parser)
    parser.add_argument(
        "--question-set",
        required=True,
        help="path to a CSV file with a 'question' and 'ground_truth' columns",
    )
    parser.add_argument(
        "--variations",
        help="path to a CSV file with variations."
        + " The following columns are supported:"
        + "\n - nRetrieved: number of documents to retrieve and include into "
        + "the prompt as context, e.g. 3, 5"
        + "\n - collection: [search engine]::[collection], e.g. PGVECTOR::langnq"
        + "\n - model: [AI engine]::[model id], e.g. BAM::ibm/granite-13b-instruct-v2"
        + "\n - parameters: JSON string with model parameters, "
        + 'e.g. {"max_new_tokens": 350}'
        + "\n - promptTemplate: prompt template string with placeholders, "
        + "e.g. Given {{context}} answer {{question}}"
        + "\n"
        + "\nA variation is made for each permutation of the column values",
    )
    parser.add_argument(
        "--output",
        required=False,
        help="path to an output CSV file to create. If --variations is set"
        + " then this path is treated as a directory.",
    )
    parser.add_argument(
        "--num-proc", default=10, help="number of processes to run in parallel", type=int
    )
    parser.add_argument(
        "--limit",
        default=0,
        help="stop after processing the first N questions (default=0 means no limit)",
        type=int,
    )
    parser.add_argument("--flow-name", help="name of the flow to evaluate (e.g. ragAnswer)")

    parser = subparsers.add_parser("ragas", help="ragas")
    _common_arguments(parser)
    parser.add_argument(
        "--response-set",
        required=True,
        help="path to a CSV file with 'question', 'ground_truth', "
        + "'answer', 'contexts' columns (see eval collect)",
    )
    parser.add_argument("--output", required=True, help="path to an output CSV file to create")
    parser.add_argument(
        "--llm",
        metavar="LLM",
        choices=[
            "ibm/granite-13b-chat-v2",
            "ibm/granite-13b-instruct-v2",
            "openai/gpt-3.5-turbo-16k",
        ],
        default="ibm/granite-13b-chat-v2",
        help="LLM to evaluate the RAG pipeline answers",
    )
    parser.add_argument(
        "--limit",
        default=0,
        help="stop after processing the first N responses (default=0 means no limit)",
        type=int,
    )


def check_embedding_model(model_name: str) -> str:
    # would like to  do a check based upon the AI Engine in effect
    # but that requires us to call an API (BAM, etc.) or know the
    # valid values (watsonx)
    return model_name


def main():
    load_dotenv()
    _init_logger()
    me = sys.argv[0]
    if not me:
        me = "flows"
    else:
        me = os.path.basename(me)
    parser = argparse.ArgumentParser(
        prog=me, description="cli for watsonx.ai flows engine development", epilog=""
    )
    # one or more feature flags
    parser.add_argument(
        "--feature-flag", "-F", dest="feature_flags", action="append", help=argparse.SUPPRESS
    )
    parser.add_argument("--verbose", "-v", action="store_true", default=False, help="verbose")

    parser.add_argument("--version", action="version", version="%(prog)s " + cmd_version)

    subparsers = parser.add_subparsers(required=True)
    _setup_init(subparsers.add_parser("init", help="initialize"))
    _setup_login(subparsers.add_parser("login", help="login"))
    _setup_whoami(subparsers.add_parser("whoami", help="whoami"))
    _setup_deploy(subparsers.add_parser("deploy", help="deploy"))
    _setup_collection(subparsers.add_parser("collection", help="collection"))
    _setup_graph(subparsers.add_parser("flows", help="flow or flows"))
    _setup_data(subparsers.add_parser("data", help="data builder"))
    _setup_eval(subparsers.add_parser("eval", help="RAG pipeline evaluation"))

    args = parser.parse_args()
    try:
        location = args.location
    except AttributeError:
        # would allow pointing to a different
        # location for .env - todo: remove
        location = ""

    try:
        clienv = cmd_setup(location, args.feature_flags, args.verbose, args.command)
        if args.command == "init":
            cmd_init(
                clienv,
                args.pattern,
                args.collection,
                args.files,
                args.name,
                args.email,
                args.interactive,
                args.configuration_file,
                args.initial_configuration_file,
                check_embedding_model(args.embedding_model),
                DataArguments(args).get_data(),
                args.endpoint_name,
                args.preexisting_endpoint,
                args.ai_engine,
                DocumentStoreArguments(
                    args.document_store,
                    args.document_store_data_file,
                ),
            )
        elif args.command == "login":
            cmd_login(
                clienv,
                args.environment,
                args.adminkey,
                args.domain,
                args.introspection,
            )
        elif args.command == "deploy":
            cmd_deploy(
                clienv,
                TOMLConfiguration(args.watzen_configuration),
                ExtensionsArguments(args),
                args.configuration_file,
                args.flow,
                args.flow_file,
                args.working_directory,
                args.working_directory_unsafe_dump_final_config_yaml,
                "skip",  # deploy is flows only
            )
            pass
        elif args.command == "collection":
            cmd_deploy(
                clienv,
                TOMLConfiguration(args.watzen_configuration),
                ExtensionsArguments(args),
                args.configuration_file,
                args.flow,
                args.flow_file,
                args.working_directory,
                args.working_directory_unsafe_dump_final_config_yaml,
                args.collection_mode,
            )
        elif args.command == "flow" or args.command == "flows" or args.command == "graph":
            cmd_graph(
                clienv,
                args.subcommand,
                TOMLConfiguration(args.watzen_configuration),
                ExtensionsArguments(args),
                args.configuration_file,
                args.flow,
                args.flow_file,
                args.working_directory,
            )
        elif args.command == "data":
            if args.subcommand == "annotate":
                cmd_data_annotate(
                    console,
                    clienv,
                    TOMLConfiguration(args.watzen_configuration),
                    args.directive,
                    args.embedding_model,
                    args.files,
                    args.output_file,
                    args.force,
                )
            elif args.subcommand == "build":
                cmd_data(
                    console,
                    clienv,
                    TOMLConfiguration(args.watzen_configuration),
                    args.subcommand,
                    DataArguments(args).get_data(),
                    args.force,
                )
        elif args.command == "whoami":
            cmd_whoami(clienv, args.showkeys)
        elif args.command == "eval":
            if args.subcommand == "collect":
                cmd_eval_collect(
                    clienv,
                    args.subcommand,
                    TOMLConfiguration(args.watzen_configuration),
                    args.flow_name,
                    args.question_set,
                    args.output,
                    args.variations,
                    args.num_proc,
                    args.limit,
                )
            elif args.subcommand == "ragas":
                cmd_eval_ragas(
                    clienv,
                    args.subcommand,
                    args.response_set,
                    args.output,
                    args.llm,
                    args.limit,
                )
            else:
                raise CLIError(f"unknown command: {CLI_NAME} eval {args.subcommand}")
    except CLIError as e:
        console.print(
            "\n[red]Error[/red]:",
            e.message if isinstance(e.message, ConsoleRenderable) else escape(e.message),
        )
        sys.exit(e.code)


if __name__ == "__main__":
    main()
